#NAME
#TP
#Individual Assignment


#=============INTALL PACKAGES=================#

install.packages("ggplot2")
install.packages("dplyr")
install.packages("crayon")
install.packages("hexbin")
install.packages("ggridges")
install.packages("tidyr")
install.packages("lessR")
install.packages("Rfast")
install.packages("plotrix")
install.packages("ggpubr")





#=============LOAD LIBRARIES==================#

library("ggplot2")
library("dplyr")
library("crayon")
library("hexbin")
library("ggridges")
library("lessR")
library("Rfast")
library("plotrix")
library("ggpubr")
library("tidyr")



#============IMPORT DATASET====================#

placement_data=read.csv("C://Yan//PFDA//DataSet_2//Placement_Data_Full_Class.csv")
placement_data

View(placement_data)
#============ASSIGN THE HEADERS================#

names(placement_data) =c("sl_no" , "gender" , "age" , "address" , "Medu" , "Fedu" , "Mjob" ,
                    "Fjob" , "famsup", "paid" , "activities" , "internet", "ssc_p", 
                    "ssc_b",	"hsc_p",	"hsc_b",	"hsc_s",	'degree_p',	"degree_t",	"workex",	
                    "etest_p",	"specialisation",	"mba_p",	"status",	"salary")

												

-------------------------------------------------------------

#==============DATA MANIPULATION==============#

# Question 1: What factors are important for getting placed?
# Analysis 1-1: Visualize the distribution of salary.

ggplot(placement_data, aes(x = salary)) +
  geom_histogram(fill = "darkblue", color = "white") +
  labs(title = "Salary Distribution", x = "Salary", y = "Count")

# Analysis 1-2: Explore the relationship between percentage degree with salary.


degr=cor(placement_data$degree_p, placement_data$salary)
degr

ggplot(placement_data, aes(x = degree_p, y = salary)) + 
  geom_point() + 
  labs(x = "Percentage of Degree", y = "Salary") +
  ggtitle("Relationship between Percentage of Degree and Salary")

# Analysis 1-3: Investigate the relationship between work experience, gender, and getting placed.
ggplot(placement_data, aes(x = gender, fill = status)) +
  geom_bar(position = "dodge") +
  labs(title = "Gender vs Placement Status", x = "Gender", y = "Count")

ggplot(placement_data, aes(x = workex, fill = status)) +
  geom_bar(position = "dodge") +
  labs(title = "Work Experience vs Placement Status", x = "Work Experience", y = "Count")

# Question 2: Is there any correlation between family education background and placement status?
# Analysis 2-1: Count the number of people who have a father and mother with high education background and have placed.
high_edu_placed <- placement_data[placement_data$Medu %in% c(3, 4) & 
                                    placement_data$Fedu %in% c(3, 4) & 
                                    placement_data$status == "Placed",]
n_high_edu_placed <- nrow(high_edu_placed)
cat("The number of people who have a father and mother with high education background and have placed is", 
    n_high_edu_placed, "\n")
ggplot(high_edu_placed, aes(x = age)) + 
  geom_histogram(binwidth = 1, fill = "blue", alpha = 0.5) + 
  ggtitle("Distribution of Age for People with High Education Background and Placed") + 
  xlab("Age") + ylab("Count")

# Analysis 2-2: Compare the percentage of placed students from rural and urban areas.
placement_data %>%
  group_by(address) %>%
  summarize(placed_percentage = mean(status == "Placed")) %>%
  ggplot(aes(x = address, y = placed_percentage)) +
  geom_bar(stat = "identity", fill = "darkblue") +
  labs(title = "Placement Status by Address", x = "Address", y = "Placement Percentage")

# Analysis 2-3: Explore the relationship between having family support and placement status.

ggplot(placement_data, aes(x = famsup, fill = status)) +
  geom_density(alpha = 0.5) +
  labs(title = "Family Support vs Placement Status", x = "Family Support", y = "Density") +
  scale_fill_manual(values = c("#1B9E77", "#D95F02")) +
  theme_classic() +
  facet_wrap(~status, ncol = 1, scales = "free_y")

# Question 3: How does the academic background affect the placement rate?
# Analysis 3-1: Visualize the distribution of placement status for different streams in 12th
placement_data %>%
  group_by(hsc_s, status) %>%
  summarise(n = n()) %>%
  mutate(prop = n / sum(n)) %>%
  ggplot(aes(x = hsc_s, y = prop, fill = status)) +
  geom_bar(stat = "identity", position = "dodge", alpha = 0.8) +
  labs(x = "Stream in 12th", y = "Proportion of students", fill = "Placement status") +
  ggtitle("Distribution of placement status for different streams in 12th") +
  geom_errorbar(aes(ymin = prop - qnorm(0.975) * sqrt(prop * (1 - prop) / n),
                    ymax = prop + qnorm(0.975) * sqrt(prop * (1 - prop) / n)),
                position = position_dodge(width = 0.9), width = 0.2) +
  theme_classic()

# Analysis 3-2: Compare the percentage of placed students from different degrees
degree_placed <- placement_data %>% group_by(degree_t) %>% summarize(placed = sum(status=="Placed"), total = n()) %>%
  mutate(percentage = placed/total*100)
degree_placed
ggplot(degree_placed, aes(x=degree_t, y=percentage)) +
  geom_bar(stat="identity", fill="steelblue") +
  labs(x="Degree", y="Percentage of placed students", title="Percentage of placed students from different degrees")

# Analysis 3-3: Explore the relationship between the score of a candidate in different subjects and getting placed
ggplot(placement_data, aes(x=ssc_p, y=degree_p, color=status)) +
  geom_point() +
  labs(x="Secondary Education Percentage", y="Degree Percentage", color="Placement Status") +
  ggtitle("Relationship between the score of a candidate in different subjects and getting placed")

# Question 4: How much does the specialization affect the placement rate?
# Analysis 4-1: Compare the percentage of placed students from different specializations
specialization_placed <- placement_data %>% group_by(specialisation) %>% summarize(placed = sum(status=="Placed"), total = n()) %>%
  mutate(percentage = placed/total*100)
specialization_placed
ggplot(specialization_placed, aes(x=specialisation, y=percentage)) +
  geom_bar(stat="identity", fill="steelblue") +
  labs(x="Specialization", y="Percentage of placed students", title="Percentage of placed students from different specializations")

# Analysis 4-2: Investigate the relationship between the specialization and salary
ggplot(placement_data, aes(x=specialisation, y=salary, fill=status)) +
  geom_boxplot() +
  labs(x="Specialization", y="Salary", fill="Placement Status") +
  ggtitle("Relationship between the specialization and salary")

# Analysis 4-3: Visualize the distribution of percentage of specializations for placed and non-placed students
ggplot(placement_data, aes(x=specialisation, fill=status)) + 
  geom_bar(position="dodge", color="black", size=0.3) +
  scale_fill_manual(values=c("#E69F00", "#0072B2")) +
  labs(x="Specialization", y="Number of students", fill="Placement status") +
  ggtitle("Distribution of percentage of specializations for placed and non-placed students") +
  theme_classic() +
  theme(plot.title = element_text(size=16, face="bold"),
        axis.title = element_text(size=14, face="bold"),
        axis.text = element_text(size=12, face="bold"),
        legend.title = element_text(size=12, face="bold"),
        legend.text = element_text(size=10, face="bold"))


